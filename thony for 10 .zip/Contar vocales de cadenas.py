#Contar vocales en una cadena

texto=input("Ingrese texto:")
vocales="a,e,i,o,u"
x=0

for i in texto:
    if i in vocales:
        x=x+1
        
print(f"El texto tiene:{x} vocales")

