#sumar los primos N numero naturales

nnn=int(input("Ingrese nnn:"))
x=0
for i in range( nnn>0):
    if nnn>0:
     i= nnn%nnn ==0
     x=x-1
     
print(f"{i}")