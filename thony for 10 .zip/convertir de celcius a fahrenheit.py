#Convertir grados Celsius a Fahrenheit

c=int(input("ingrese la cantidad:"))
F=int(input("Ingrese la cantidad :"))

for i in range (c,F+1):
    fa=c*9/5+32
    
print(f"la cantidad de celcius es:{c} y la cantidad de Fahrenheit es de: {fa}")

    