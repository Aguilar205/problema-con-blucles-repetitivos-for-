#imprimir una serie de numero

nu=int(input("Ingrese numero:"))
x=0
for i in range (1,10):
  if nu % 2 == 0:
      x+= 1
      print(f"{nu}")
    
