#Determinar si un número es primo

numero=int(input("ingrese nuemro:"))
a=0

for i in ranger(1,numero+1):
    if numero % 1 ==0:
        a=a+1
        
if a >2:
    print("El numero",numero," no es primo")
    
else:
    print("El numero",numero,"si es primo")
    
    