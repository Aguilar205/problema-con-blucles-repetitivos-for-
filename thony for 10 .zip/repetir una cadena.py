#Repetir una cadena

txt=input("Ingrese texto:")
nnn=int(input("Ingrese numero:"))

for in range (nnn):
print(f"El texto{txt} un candidad de {nnn}")
    

