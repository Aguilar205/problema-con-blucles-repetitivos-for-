#Imprimir números impares:

numero=int(input("Ingrese numero:"))

for i in range(numero>0):
    if numero % 2 ==1:
        print(f"impares:{numero}")
    
    
    