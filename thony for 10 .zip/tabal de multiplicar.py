#Tabla de multiplicar

numero=int(input("Ingrese numero:"))

for i in range (1,11):
    print(numero,"por",i, "es igual a:",numero*i)
    