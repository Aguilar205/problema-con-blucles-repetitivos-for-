##sumar los primos N numero naturales

nnn=int(input("Ingrese nnn:"))
x=0
for i in range(nnn):
    if nnn>0:
     x=x + i
print(f"{x}")