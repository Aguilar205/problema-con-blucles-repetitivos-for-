#Sumar números pares del 1 al 100

numero=int(input("ingrese numero:"))

for i in  range(1,11):
    print(numero,"mas",i ,"es igual a:",numero+i)