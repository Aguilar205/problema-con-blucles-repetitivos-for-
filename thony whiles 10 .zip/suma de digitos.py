#Suma  dígitos de un número

numero=int(input("Ingrese el numero:"))

su=0
while numero > 0:
    
    su=su + (numero %10)
    numero= numero // 10
    
    print(f"suma de digitos de un numero:{su}")
    