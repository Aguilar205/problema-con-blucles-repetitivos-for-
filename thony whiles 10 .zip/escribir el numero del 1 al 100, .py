# escriba el numero del 1 al 100
numero= 1
suma= 0

while numero <=100:
    
    suma= suma + numero
    
    numero= numero + 1
    
    print(f"suma entre el numero del 1 al 100:{suma}")

