# convertir de decimales a binario

decimal=int(input("Ingrese numero:"))
z=0

while decimal !=z:
    resi=decimal % 2
    resis=resi//2
    print(f"Decimal {decimal} en binario{resi}")
    
    