n = int(input("Ingrese un número entero positivo: "))  # Solicitar al usuario que ingrese un número
x = 1  # Inicializar el contador de múltiplos en 1
c = 10  # Establecer el límite de múltiplos que queremos mostrar

while x <= c:
    # Calcular el múltiplo e imprimirlo
    multiplo = n * x
    print(f"{n} x {x} = {multiplo}")
    x=x+1