#Sumar números hasta un límite:

numero=int(input("ingrese numero:"))
su=0
c=0
while su <=numero:
    su=su+numero
    c+=1
print(f"Suma del limiti es:{su}")

