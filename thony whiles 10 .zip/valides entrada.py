#validar entrada

numero=int(input("Ingrese numero:"))
it=0

while numero < it:
    
    if numero > 0:
        print(f"valido:{numero}")
        

    else:
        print(f"invalido:{numero}")
        numero*=-1
        
        print(f"correcto:{numero}")
        


        
        
        
    