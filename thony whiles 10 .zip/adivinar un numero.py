#Adivinar un número
import random 
numero_secreto= random.randint(1,100)
intentos=0 

while intentos != numero_secreto:
    
    intentos=int(input("adivina el numero entre el 1 al 100:"))
    
    if intentos < 100:
        print("numero bajo")
    elif intentos> 100:
        print("numero alto")
    
else:
    print ("! felicidade¡")
        
