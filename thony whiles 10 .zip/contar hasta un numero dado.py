#Contar hasta un número dado

numero=1
nu=int(input("ingrese numeros:"))


while numero <= nu:
    print(numero)
    numero= numero + 1
    
    print:(f"finalizar programa:,{numero}")
      
    