#Simular un cajero automático

pin=int(input("Ingrese el pin:"))
x=0
pi=1
while pin != x:
    if pin ==pi :
     print("contraseña correcta")
     x=x+1
     
    if pin > pi:
        print("contraseña incorrecta")
        
    intento_1=int(input("1-ingrese pin:"))
    
    if pin> pi:
        print("contraseña incorrecta")
      
    intento_2=int(input("2-ingrese pin:"))
    if pin> pi:
       print("contraseña incorrecta")
       x=x+1
    
    
else:
     print("!bloquedo¡")
     x=x+1
 
  
    
    
    
